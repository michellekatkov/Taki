﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taki
{
    public partial class Form5 : Form
    {
        PictureBox current = new PictureBox();

        public Form5()
        {
            InitializeComponent();
            PictureBox c = new PictureBox();
            c.Load(@"C:\\Users\\Sergey\\Desktop\\1_green.png");
            c.Show();
            Give_to_deck.Interval = 10;
            Give_to_deck.Tick += new EventHandler(timer1_Tick);
            Player1.Interval = 10;
            Player1.Tick += new EventHandler(Player1_Tick);
            Player2.Interval = 10;
            Player2.Tick += new EventHandler(Player2_Tick);
            Player3.Interval = 10;
            Player3.Tick += new EventHandler(Player3_Tick);
        }

        public void show_if_empty(PictureBox p)
        {
            
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }
  
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Show();
            Give_to_deck.Start();
        }

  
        private void timer2_Tick(object sender, EventArgs e)
        {

        }
      
        private void timer1_Tick(object sender, EventArgs e)
        {
            current = pictureBox1;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x, y-5);

            if (y < pictureBox3.Location.Y)
            {
                Give_to_deck.Stop();
                current.Image = null;
                pictureBox3.Load( @"C:\\Users\\Sergey\\Desktop\\1_green.png");

            }

        }

        private void Player1_Tick(object sender, EventArgs e)
        {
            current = pictureBox2;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x, y + 5);

            if (y > pictureBox3.Location.Y)
            {
                Player1.Stop();
                current.Image = null;
                pictureBox3.Load(@"C:\\Users\\Sergey\\Desktop\\1_blue.png");

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox2.Show();
            Player1.Start();

        }

        private void Player2_Tick(object sender, EventArgs e)
        {
             current = pictureBox4;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x-5, y );

            if (x < pictureBox3.Location.X)
            {
                Player2.Stop();
                current.Image = null;
                pictureBox3.Load(@"C:\\Users\\Sergey\\Desktop\\1_blue.png");

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Player2.Start();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Player3.Start();
        }

        private void Player3_Tick(object sender, EventArgs e)
        {
            current = pictureBox5;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x + 5, y);

            if (x > pictureBox3.Location.X )
            {
                Player3.Stop();
                current.Image = null;
                pictureBox3.Load(@"C:\\Users\\Sergey\\Desktop\\1_blue.png");

            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
    }
}
