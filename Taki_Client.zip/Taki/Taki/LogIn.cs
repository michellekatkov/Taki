﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Taki
{
     public partial class LogIn : Form
    {
        public static string name ;

        public LogIn()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;

            if (txt_UserName.Text == "" || txt_password.Text == "")
            {
                MessageBox.Show("Please provide UserName and Password");
                return;
            }

            else
            {
            count = 1;
                name = txt_UserName.Text;
            }
            try
            {


                //If count is equal to 1, than show frmMain form
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    this.Hide();
                    var new_form = new Form5();
                    new_form.Show();
                }
                else
                {
                    MessageBox.Show("Login Failed!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }
    }
}
    

