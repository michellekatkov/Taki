﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Taki
{
    public partial class Form4 : Form
    {
        string type = "red1";
        Image im;
        int count_help = 0;
        int count_help1 = 0;
        PictureBox b1 = new PictureBox();
        PictureBox help = new PictureBox();
        PictureBox current = new PictureBox();
        string player_one="";
        string player_two;
        string player_three;
        int x_of_new_picturebox;
        string image = @"C:\\Users\\Sergey\\Desktop\\1_blue.png";

        public Form4()
        {
            InitializeComponent();
            //get_number_of_cards(9, "");

            check_for_empty();

            //b1.Load ( @"C:\\Users\\Sergey\\Desktop\\Taki Pictures\\9_red.png");
            timer2.Interval = 10;
            timer1.Interval = 10;
            timer1.Tick += new EventHandler(timer_Tick);
            timer2.Tick += new EventHandler(timer2_Tick);
            timer2.Start();
            Give_to_deck.Interval = 10;
            Give_to_deck.Tick += new EventHandler(Give_to_deck_Tick);
            player1.Interval = 10;
            player1.Tick += new EventHandler(player1_Tick);
            playe2.Interval = 10;
            playe2.Tick += new EventHandler(player1_Tick);
            //Draw_image(pictureBox1,image);

            //player NAME!!!
            string Player_name = Log_in.Name_Text;
            //LOBI_NAME!!!!!
            string Lobi_name= Log_in.Lobi_Text;
            label1.Text = Player_name;
            //pictureBox2.Load(@"C:\\Users\\Sergey\\Desktop\\1_blue.png");
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
        }
      

        public void get_number_of_cards(int num_of_cards,string player_name)
        {
            //get number of cards
            if (player_name == player_one)
            {
               PictureBox[] cards = {pictureBox17,pictureBox18,pictureBox19,pictureBox20, pictureBox21, pictureBox22, pictureBox23, pictureBox24 };
                //PictureBox[] additional_cards = {pictureBox35,pictureBox38,pictureBox39,pictureBox40};
                if (num_of_cards > 8)
                {
                    int num_of_neadless_cards = num_of_cards - 8;
                    int location = pictureBox17.Location.X;
                    int x = pictureBox17.Location.X;
                    int y = pictureBox17.Location.Y;
                    PictureBox imageControl;
                    for (int i = 0; i < num_of_neadless_cards; i++)
                    {
                        imageControl = new PictureBox();
                        imageControl.Height = pictureBox17.Height;
                        Controls.Add(imageControl);
                        imageControl.Load(@"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");
                        imageControl.SizeMode = PictureBoxSizeMode.Zoom;

                        imageControl.Location = new Point(x - 25, y + imageControl.Height);
                        y += imageControl.Height;
                    }
                }
                if (num_of_cards <= 8 && num_of_cards != 0)
                {
                    int c = 8 - num_of_cards;
                    for (int i = 0; i < c; i++)
                    {
                        if (c > 0 && cards[i].Image != null)
                        {
                            cards[i].Image = null;
                        }
                    }
                }
                else if (num_of_cards == 0)
                    MessageBox.Show(player_name+" Have won");


            }
            else if (player_name == player_three)
            {
                PictureBox[] cards = { pictureBox9, pictureBox10, pictureBox11, pictureBox12, pictureBox13, pictureBox14, pictureBox15, pictureBox16 };
                //PictureBox[] additional_cards = {pictureBox45,pictureBox46,pictureBox47,pictureBox48 };
                if (num_of_cards > 8)
                {
                    int num_of_neadless_cards = num_of_cards - 8;
                    int location = pictureBox9.Location.X;
                    int x = pictureBox9.Location.X;
                    int y = pictureBox9.Location.Y;
                    PictureBox imageControl;
                    for (int i = 0; i < num_of_neadless_cards; i++)
                    {
                        imageControl = new PictureBox();
                        imageControl.Height = pictureBox9.Height;
                        Controls.Add(imageControl);
                        imageControl.Load(@"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");
                        imageControl.SizeMode = PictureBoxSizeMode.Zoom;

                        imageControl.Location = new Point(x + imageControl.Height + 15, y);
                        x += imageControl.Height + 15;
                    }

                    //Draw_image(additional_cards[i], @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");

                }
                if (num_of_cards <= 8 && num_of_cards != 0)
                {
                    int c = 8 - num_of_cards;
                    for (int i = 0; i < c; i++)
                    {
                        if (c > 0 && cards[i].Image != null)
                        {
                            cards[i].Image = null;
                        }
                    }
                }
                else if (num_of_cards == 0)
                    MessageBox.Show(player_name+"Have won");

            }

            else if (player_name == player_two)
            {
                PictureBox[] cards = { pictureBox25, pictureBox26, pictureBox27, pictureBox28, pictureBox29, pictureBox30, pictureBox31, pictureBox32 };
                //PictureBox[] additional_cards = { pictureBox41,pictureBox42,pictureBox43,pictureBox44};
                if (num_of_cards > 8)
                {
                    int num_of_neadless_cards = num_of_cards - 8;
                    int location = pictureBox32.Location.X;
                    int x = pictureBox32.Location.X;
                    int y = pictureBox32.Location.Y;
                    PictureBox imageControl;
                    for (int i = 0; i < num_of_neadless_cards; i++)
                    {
                        imageControl = new PictureBox();
                        imageControl.Height = pictureBox32.Height;
                        Controls.Add(imageControl);
                        imageControl.Load(@"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");
                        imageControl.SizeMode = PictureBoxSizeMode.Zoom;

                        imageControl.Location = new Point(x - 25, y + imageControl.Height);
                        y += imageControl.Height;
                    }
                    //Draw_image(additional_cards[i], @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");

                }
                if (num_of_cards <= 8 && num_of_cards != 0)
                {
                    int c = 8 - num_of_cards;
                    for (int i = 0; i < c; i++)
                    {
                        if (c > 0 && cards[i].Image != null)
                        {
                            cards[i].Image = null;
                        }
                    }
                }
                else if (num_of_cards == 0)
                    MessageBox.Show(player_name+"Have won");

            }
            else
            {
                PictureBox[] cards = { pictureBox1, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7, pictureBox8 };
                //PictureBox[] additional_cards = { pictureBox41,pictureBox42,pictureBox43,pictureBox44};
                if (num_of_cards > 8)
                {
                    int num_of_neadless_cards = num_of_cards - 8;
                    int location = pictureBox8.Location.X;
                    int x = pictureBox8.Location.X;
                    int y = pictureBox8.Location.Y;
                    PictureBox imageControl;
                    for (int i = 0; i < num_of_neadless_cards; i++)
                    {
                        imageControl = new PictureBox();
                        imageControl.Height = pictureBox8.Height;
                        Controls.Add(imageControl);
                        imageControl.Load(image);
                        imageControl.SizeMode = PictureBoxSizeMode.Zoom;

                        imageControl.Location = new Point(x + imageControl.Height + 15, y);
                        x += imageControl.Height + 15;
                    }

                    //Draw_image(additional_cards[i], @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");

                }
                if (num_of_cards <= 8 && num_of_cards != 0)
                {
                    int c = 8 - num_of_cards;
                    for (int i = 0; i < c; i++)
                    {
                        if (c > 0 && cards[i].Image != null)
                        {
                            cards[i].Image = null;
                        }
                    }
                }
                else if (num_of_cards == 0)
                    MessageBox.Show(player_name+"Have won");

            }
        }

        public void give_card(string player_name,PictureBox card)
        {
            Whose_turn.Text = player_name;
            Deck1.Image = card.Image;
            
        }
         void timer_Tick(object sender, EventArgs e)
        {
            int x = Transition.Location.X;
            int y = Transition.Location.Y;
            Transition.Location = new Point(x, y+5);

            if (y > pictureBox2.Location.Y-Transition.Height)
            {
                timer1.Stop();
                Transition.Image = null;
                Draw_image(current, image);
                //Transition.Image=null;
                return_Transition();
            }

        }
        void return_Transition()
        {
            Transition.Location = Deck1.Location;
            Draw_image(Transition, @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");

        }
        public void check_for_empty()
        {
            PictureBox[] p = { pictureBox1, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7,
                pictureBox8};
            foreach (var pb in this.Controls.OfType<PictureBox>())
            {
                PictureBox b = (PictureBox)pb;
                if (b.Image == null)
                {
                    Draw_image(b, @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png");
                }
                for (int i = 0; i < p.Length; i++)
                {
                    if (b.Name == p[i].Name)
                        b.Image = null;
                }
                
            }
        }

        public static void Draw_image(PictureBox pictureBox1,string image)
        {
            pictureBox1.Load(image);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

        }
       
        private void Form4_Load(object sender, EventArgs e)
        {

        }
     
        private void pictureBox4_Click(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      
        private void pictureBox34_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox33_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            PictureBox[] p = {pictureBox1,pictureBox2,pictureBox3,pictureBox4,pictureBox5,pictureBox6,pictureBox7
                    ,pictureBox8};
            for (int i = 0; i < p.Length; i++)
            {
                if(p[i].Image==null||p[i].Image.Equals( @"C:\\Users\\Sergey\\Desktop\\Taki pictures\\over.png"))
                {
                    current = p[i];
                    timer1.Start();
                }
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        void return_card_toplace()
        {
            current.Location = help.Location;
        }
        private void Give_to_deck_Tick(object sender, EventArgs e)
        {
            current = pictureBox1;
            count_help++;
            if(count_help==1)
                help.Location = current.Location;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x, y - 5);

            if (y < Deck1.Location.Y)
            {
                Give_to_deck.Stop();
                //Deck1.Image = null;
                Deck2.Image = current.Image;
                current.Image = null;
                return_card_toplace();
                count_help = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Show();
            Give_to_deck.Start();
        }

        private void Deck2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        
        private void player1_Tick(object sender, EventArgs e)
        {
            current = pictureBox21;
            count_help++;
            if (count_help == 1)
                help.Location = current.Location;
            int x = current.Location.X;
            int y = current.Location.Y;

            current.Location = new Point(x - 5, y);

            if (x < Deck2.Location.X)
            {
                player1.Stop();
                current.Image = null;
                Deck2.Image=current.Image;
                return_card_toplace();
                count_help = 0;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            current.Show();
            player1.Start();
        }

        private void player2_Click(object sender, EventArgs e)
        {
            current.Show();
            playe2.Start();
        }

        private void playe2_Tick(object sender, EventArgs e)
        {
            current = pictureBox27;
            count_help++;
            if (count_help == 1)
                help.Location = current.Location;
            int x = current.Location.X;
            int y = current.Location.Y;


            current.Location = new Point(x + 5, y);

            if (x > Deck2.Location.X)
            {
                playe2.Stop();
                current.Image = null;
                Deck2.Image=current.Image;
                return_card_toplace();
                count_help = 0;
            }

        }

        private void pictureBox32_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            current.Show();
            Give_to_deck.Start();
        }

        private void pictureBox35_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox40_Click(object sender, EventArgs e)
        {

        }
    }
}
