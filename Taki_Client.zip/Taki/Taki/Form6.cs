﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taki
{
    public partial class Log_in : Form
    {
        public static string Name_Text = "";
        public static string Lobi_Text = "";

        public Log_in()
        {
            InitializeComponent();
        }

        private void Log_in_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Name_Text = txt_UserName.Text;
            Lobi_Text = txt_Password.Text;
            int count = 0;
            if (txt_UserName.Text == "" || txt_Password.Text == "")
            {
                MessageBox.Show("Please provide UserName and Password");
                return;
            }
   
            else
            {
                count = 1;
                try
                {
                    //Create SqlConnection
                    //If count is equal to 1, than show frmMain form

                    if (count == 1)
                    {
                        MessageBox.Show("Login Successful!");
                        this.Hide();
                        var new_form = new Form4();
                        new_form.Show();
                    }
                    else
                    {
                        MessageBox.Show("Login Failed!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
    
